CREATE VIEW ZXL_NSR_GD AS select a.nsrsbh,b."NSRDZDAH",b."PZXH",b."XH",b."GDMC",b."ZJLX_DM",b."ZJHM",b."JJXZ",b."TZBL",b."ZCDZ" from dj_nsrxx a,(SELECT b.nsrdzdah,a.* FROM sb_ndsds_2014_jcxx_gd a,sb_ndsds_2014 b where a.pzxh=b.pzxh) b where a.nsrdzdah=b.nsrdzdah
/
