CREATE VIEW ZXL_JCAJXX_1 AS SELECT t.jcajxh,t.nsrdzdah,t.jcajmc,t.aydjrq,q.wfwzlx_mc FROM jc_ajxx t left outer join dm_wfwzlx q on t.wfwzlx_dm=q.wfwzlx_dm
/
