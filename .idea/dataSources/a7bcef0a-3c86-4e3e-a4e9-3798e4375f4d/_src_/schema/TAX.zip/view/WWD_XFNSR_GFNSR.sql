CREATE VIEW WWD_XFNSR_GFNSR AS SELECT
    NSR1.VERTEXID as xf_VERTEXID,
    NSR2.VERTEXID as gf_VERTEXID,
    sl,je,se,jybl
from 
(
    select a.XF_NSRSBH,a.GF_NSRSBH,sl,je,se,GREATEST(a.je/b.SUM_JE,a.JE/C.SUM_JE,0.2) as jybl from 
    (
    select XF_NSRSBH,GF_NSRSBH,sl,sum(je) as je,sum(se) as se
    from AA_FPCGL_2014 trade
    where je>0 and se>0 and sl>0 and ZFBZ = 'N'
    group by TRADE.XF_NSRSBH,TRADE.GF_NSRSBH,TRADE.SL
    ) a,
    (
    select XF_NSRSBH,sum(je) as sum_je
    from 
    AA_FPCGL_2014 trade
    where je>0 and se>0 and sl>0 and ZFBZ = 'N'
    group by TRADE.XF_NSRSBH) b,
   (
    select GF_NSRSBH,sum(je) as sum_je
    from 
    AA_FPCGL_2014 trade
    where je>0 and se>0 and sl>0 and ZFBZ = 'N'
    group by TRADE.GF_NSRSBH) c
    where a.XF_NSRSBH = b.XF_NSRSBH AND A.GF_NSRSBH = C.GF_NSRSBH
) trade,WWD_NSR_FDDBR nsr1,WWD_NSR_FDDBR nsr2
WHERE trade.GF_NSRSBH = NSR2.nsrsbh
AND trade.XF_NSRSBH = NSR1.nsrsbh
/
