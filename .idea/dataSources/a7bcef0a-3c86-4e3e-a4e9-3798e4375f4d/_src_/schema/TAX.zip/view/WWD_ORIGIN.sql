CREATE VIEW WWD_ORIGIN AS SELECT
	nvl(INFLU.VERTICE,nsr.VERTEXID) as vertice,
	nvl(INFLU.FINALSCORE,nsr.fz) as finalscore,
 	(
 		CASE
 		WHEN nvl(INFLU.FINALSCORE,nsr.fz) > 90 THEN
 			'A'
 		WHEN nvl(INFLU.FINALSCORE,nsr.fz) > 70 THEN
 			'B'
 		WHEN nvl(INFLU.FINALSCORE,nsr.fz) > 40 THEN
 			'C'
 		ELSE
 			'D'
 		END
 	) AS final_dm,
	nvl(NSR.NSRDZDAH,0)as NSRDZDAH,
	nvl(NSR.FZ,0) as initscore,
	nvl(NSR.XYGL_XYJB_DM,'') as init_dm,
	nvl(NSR.WTBZ,'N') as wtbz
FROM
	(
		SELECT
			*
		FROM
			WWD_INFLUENCE_RESULT
		WHERE
			finalscore > 0
	) influ
full OUTER JOIN WWD_GROUNDTRUTH nsr ON INFLU.VERTICE = NSR.VERTEXID
/
