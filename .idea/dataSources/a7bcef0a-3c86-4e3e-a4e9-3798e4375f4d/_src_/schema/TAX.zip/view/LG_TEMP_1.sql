CREATE VIEW LG_TEMP_1 AS select lg_temp."NSRDZDAH",lg_temp."SSSQ_Z",lg_temp."GDMC",lg_temp."ZJLX_DM",lg_temp."ZJHM",lg_temp."JJXZ",lg_temp."TZBL" from lg_temp, (select a.nsrdzdah,max(a.sssq_z)as sssq_z from SB_NDSDS_2014 a,SB_NDSDS_2014_JCXX_GD b where  a.PZXH=b.PZXH group by a.nsrdzdah) n where lg_temp.nsrdzdah=n.nsrdzdah and lg_temp.sssq_z=n.sssq_z
/
