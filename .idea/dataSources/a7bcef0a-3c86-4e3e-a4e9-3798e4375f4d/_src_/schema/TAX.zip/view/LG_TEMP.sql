CREATE VIEW LG_TEMP AS select a.nsrdzdah,max(a.sssq_z)as sssq_z,b.gdmc,b.zjlx_dm,b.zjhm,b.jjxz,b.tzbl from SB_NDSDS_2014 a,SB_NDSDS_2014_JCXX_GD b where  a.PZXH=b.PZXH group by a.nsrdzdah,b.gdmc,b.zjlx_dm,b.zjhm,b.jjxz,b.tzbl
/
